Dies sind die originalen Polar-Testdaten. Die Patienten sind aus echten Fällen abgeleitet.  
61 Patienten (Patient)  
* mit jeweils 1 Einrichtungskontakt (Encounter) und jeweils 1 - 3 Abteilungskontakten (Encounter)  
* mit Diagnosen (Condition)
* mit Laborwerten (Observation)
* mit Vitalwerten (Observation)
* mit Prozeduren (Procedure)
* mit Medikation (Medication, Medication Administration, Medication Statement)

      Condition                         :   270
      Encounter                         :   129
      Medication                        :   242
      MedicationAdministration          :   165
      MedicationStatement               :  3600
      Observation                       :  7006
      Patient                           :    61
      Procedure                         :    47
      -----------------------------------------
      total                             : 11520
